const siteName = 'Modern Web Co';
const url = process.env.NEXT_PUBLIC_SITE_URL || 'https://example.com';

/**
 * Global SEO configuration for the website. These values are used by the
 * `next-seo` package to populate meta tags throughout your site.
 */
const SEO = {
  defaultTitle: siteName,
  titleTemplate: `%s | ${siteName}`,
  description: 'A clean and modern web presence for a professional services company.',
  canonical: url,
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url,
    title: siteName,
    description: 'A clean and modern web presence for a professional services company.',
    images: [
      {
        url: `${url}/images/hero.jpg`,
        width: 1200,
        height: 630,
        alt: siteName,
      },
    ],
    site_name: siteName,
  },
  twitter: {
    handle: '@',
    site: '@',
    cardType: 'summary_large_image',
  },
};

export default SEO;