#!/usr/bin/env node
/*
 * Script to fetch content from Notion databases and write it to JSON files.
 * This can be run locally or within a CI environment such as GitHub Actions.
 *
 * Required environment variables:
 * - NOTION_TOKEN: Secret token for your Notion integration
 * - NOTION_BLOG_DB: Database ID for the blog posts
 * - NOTION_PAGES_DB: Database ID for regular pages (Home, Services, etc.)
 */
const fs = require('fs');
const path = require('path');
const { Client } = require('@notionhq/client');

async function fetchDatabase(notion, dbId) {
  const results = [];
  let cursor;
  do {
    const res = await notion.databases.query({ database_id: dbId, start_cursor: cursor });
    results.push(...res.results);
    cursor = res.has_more ? res.next_cursor : null;
  } while (cursor);
  return results;
}

function normalizePost(page) {
  return {
    id: page.id,
    slug: page.properties.Slug?.rich_text?.[0]?.plain_text || '',
    title: page.properties.Title?.title?.[0]?.plain_text || '',
    excerpt: page.properties.Excerpt?.rich_text?.[0]?.plain_text || '',
    content: page.properties.Content?.rich_text?.[0]?.plain_text || '',
    date: page.properties.Date?.date?.start || null,
  };
}

function normalizePage(page) {
  return {
    id: page.id,
    slug: page.properties.Slug?.rich_text?.[0]?.plain_text || '',
    title: page.properties.Title?.title?.[0]?.plain_text || '',
    content: page.properties.Content?.rich_text?.[0]?.plain_text || '',
    updated: page.last_edited_time,
  };
}

async function main() {
  const { NOTION_TOKEN, NOTION_BLOG_DB, NOTION_PAGES_DB } = process.env;
  if (!NOTION_TOKEN || !NOTION_BLOG_DB || !NOTION_PAGES_DB) {
    console.error('Missing required environment variables.');
    process.exit(1);
  }
  const notion = new Client({ auth: NOTION_TOKEN });
  // Fetch blog posts
  const blogPages = await fetchDatabase(notion, NOTION_BLOG_DB);
  const posts = blogPages.map(normalizePost).filter((p) => p.slug);
  // Fetch regular pages
  const sitePages = await fetchDatabase(notion, NOTION_PAGES_DB);
  const pages = sitePages.map(normalizePage).filter((p) => p.slug);
  // Write to JSON files
  const dataDir = path.join(__dirname, '..', 'data');
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir);
  }
  fs.writeFileSync(path.join(dataDir, 'posts.json'), JSON.stringify(posts, null, 2));
  fs.writeFileSync(path.join(dataDir, 'pages.json'), JSON.stringify(pages, null, 2));
  console.log(`Fetched ${posts.length} posts and ${pages.length} pages from Notion.`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});