import Link from 'next/link';
import Layout from '../../components/Layout';
import { getAllPosts } from '../../lib/notion';

/**
 * Blog listing page. Fetches all posts from the headless CMS (Notion or local
 * JSON) at build time and renders a list with links to individual posts.
 */
export default function Blog({ posts }) {
  return (
    <Layout>
      <section className="max-w-3xl mx-auto py-16">
        <h1 className="text-3xl sm:text-4xl font-bold mb-6 text-center">Blog</h1>
        <p className="text-gray-700 mb-8 text-center">
          Explore our latest articles on web development, design, and strategy.
        </p>
        <ul className="space-y-8">
          {posts.map((post) => (
            <li key={post.slug} className="border-b pb-6">
              <h2 className="text-2xl font-semibold mb-2">
                <Link href={`/blog/${post.slug}`} legacyBehavior>
                  <a className="text-primary hover:underline">{post.title}</a>
                </Link>
              </h2>
              <p className="text-gray-600 mb-1">{post.excerpt}</p>
              <p className="text-sm text-gray-400">{new Date(post.date).toLocaleDateString('en-US', {
                month: 'long',
                day: 'numeric',
                year: 'numeric',
              })}</p>
            </li>
          ))}
        </ul>
      </section>
    </Layout>
  );
}

export async function getStaticProps() {
  const posts = await getAllPosts();
  // Sort posts by date descending
  posts.sort((a, b) => new Date(b.date) - new Date(a.date));
  return { props: { posts } };
}