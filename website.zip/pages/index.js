import Layout from '../components/Layout';
import HeroSection from '../components/HeroSection';
import ServicesSection from '../components/ServicesSection';

/**
 * Homepage of the site. Combines the hero banner and a summary of services.
 */
export default function Home() {
  return (
    <Layout>
      <HeroSection />
      <ServicesSection />
    </Layout>
  );
}