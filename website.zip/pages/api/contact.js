import sendgrid from '@sendgrid/mail';

/**
 * API route to handle contact form submissions. Uses SendGrid to send
 * incoming messages to the configured recipient email address. Be sure to
 * configure the environment variables SENDGRID_API_KEY and CONTACT_EMAIL_TO
 * in your deployment environment (e.g. Vercel dashboard) for this to work.
 */
export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method Not Allowed' });
  }
  const { name, email, message } = req.body;
  if (!name || !email || !message) {
    return res.status(400).json({ message: 'Missing required fields' });
  }
  try {
    sendgrid.setApiKey(process.env.SENDGRID_API_KEY);
    const toEmail = process.env.CONTACT_EMAIL_TO || process.env.SENDGRID_TO_EMAIL;
    await sendgrid.send({
      to: toEmail,
      from: toEmail,
      subject: `New contact form submission from ${name}`,
      replyTo: email,
      text: message,
    });
    return res.status(200).json({ message: 'Message sent successfully' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Failed to send message' });
  }
}