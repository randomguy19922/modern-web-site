/**
 * Site footer component. Contains copyright information and optional
 * additional links. Feel free to customize with social icons or other
 * details relevant to your organisation.
 */
export default function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="bg-gray-100 mt-16">
      <div className="container mx-auto px-4 py-8 text-center text-sm text-gray-500">
        <p>&copy; {year} Modern Web Co. All rights reserved.</p>
      </div>
    </footer>
  );
}