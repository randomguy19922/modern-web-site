import Navbar from './Navbar';
import Footer from './Footer';

/**
 * Layout component that wraps pages with consistent navigation and footer.
 * The main content is pushed down to account for the fixed navbar.
 */
export default function Layout({ children }) {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      {/* Add top margin to compensate for fixed navbar height */}
      <main className="flex-1 pt-20 px-4 sm:px-6 lg:px-8">
        {children}
      </main>
      <Footer />
    </div>
  );
}