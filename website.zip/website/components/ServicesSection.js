/**
 * Displays a list of core services offered by the business. You can
 * customize the array of services to match your own offerings.
 */
export default function ServicesSection() {
  const services = [
    {
      title: 'Web Development',
      description: 'Responsive, accessible, and performant websites built with modern technologies.',
    },
    {
      title: 'SEO & Marketing',
      description: 'Optimize your presence with technical SEO, keyword research, and outreach strategies.',
    },
    {
      title: 'Content Management',
      description: 'Easily manage your content through intuitive dashboards and seamless integrations.',
    },
  ];
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl sm:text-4xl font-bold mb-4">Our Services</h2>
        <p className="text-gray-600 max-w-2xl mx-auto mb-12">
          We provide a full suite of services to take your digital presence to the next level.
        </p>
        <div className="grid md:grid-cols-3 gap-8">
          {services.map(({ title, description }) => (
            <div
              key={title}
              className="p-6 bg-white rounded-lg shadow hover:shadow-md transition-shadow"
            >
              <h3 className="text-xl font-semibold mb-2 text-primary">{title}</h3>
              <p className="text-gray-700 leading-relaxed">{description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}