import Image from 'next/image';
import Link from 'next/link';

/**
 * Hero section for the home page. Displays a large background image,
 * a headline, and a call‑to‑action button. Customize the text and link
 * destinations as needed.
 */
export default function HeroSection() {
  return (
    <div className="relative bg-gray-800 text-white rounded-lg overflow-hidden mb-12">
      <div className="absolute inset-0 h-full w-full">
        <Image
          src="/images/hero.jpg"
          alt="Modern office"
          layout="fill"
          objectFit="cover"
          quality={80}
          priority
        />
        <div className="absolute inset-0 bg-gray-900 opacity-50" />
      </div>
      <div className="relative z-10 px-6 py-32 text-center sm:px-10">
        <h1 className="text-4xl sm:text-6xl font-bold mb-4">Elevate Your Digital Presence</h1>
        <p className="text-lg sm:text-2xl mb-8 max-w-3xl mx-auto">
          We build modern, performant, and beautiful websites tailored to your business.
        </p>
        <Link href="/services" legacyBehavior>
          <a className="inline-block bg-primary hover:bg-primary-dark text-white px-8 py-3 rounded-md transition-colors">
            View Our Services
          </a>
        </Link>
      </div>
    </div>
  );
}