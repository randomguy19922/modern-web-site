import Link from 'next/link';
import { useRouter } from 'next/router';

/**
 * Primary navigation component. Highlights the active route and provides
 * links to each major page. Adjust the routes or styling here to match
 * your brand.
 */
export default function Navbar() {
  const router = useRouter();
  const links = [
    { href: '/', label: 'Home' },
    { href: '/services', label: 'Services' },
    { href: '/about', label: 'About' },
    { href: '/blog', label: 'Blog' },
    { href: '/contact', label: 'Contact' },
  ];
  return (
    <nav className="bg-white shadow fixed w-full z-10">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="text-2xl font-bold text-primary">Modern Web Co</div>
        <ul className="flex space-x-6">
          {links.map(({ href, label }) => {
            const isActive = router.pathname === href || (href !== '/' && router.pathname.startsWith(href));
            return (
              <li key={href}>
                <Link href={href} legacyBehavior>
                  <a className={
                    isActive
                      ? 'text-secondary font-semibold'
                      : 'text-gray-700 hover:text-primary transition-colors'
                  }>
                    {label}
                  </a>
                </Link>
              </li>
            );
          })}
        </ul>
      </div>
    </nav>
  );
}