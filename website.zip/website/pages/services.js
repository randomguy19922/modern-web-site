import Layout from '../components/Layout';

/**
 * Services page. Provides a more detailed overview of offerings. You can
 * refine the descriptions to match your actual services.
 */
export default function Services() {
  const services = [
    {
      title: 'Custom Web Development',
      description:
        'From landing pages to complex web applications, we build responsive and performant sites using the latest technologies.',
    },
    {
      title: 'Search Engine Optimization',
      description:
        'Improve your visibility with technical SEO audits, keyword research, on‑page optimization, and strategic link building.',
    },
    {
      title: 'Content Strategy & Management',
      description:
        'We help you plan, create, and manage content that engages your audience and drives conversions, powered by a headless CMS.',
    },
  ];
  return (
    <Layout>
      <section className="max-w-5xl mx-auto py-16">
        <h1 className="text-3xl sm:text-4xl font-bold mb-6 text-center">Services</h1>
        <p className="text-gray-700 max-w-3xl mx-auto text-center mb-12">
          We offer a suite of services designed to help your business thrive online. Whether you’re looking to launch a new site or revamp an existing one, our team has you covered.
        </p>
        <div className="space-y-8">
          {services.map(({ title, description }) => (
            <div key={title} className="p-6 bg-white rounded-lg shadow hover:shadow-md transition-shadow">
              <h2 className="text-2xl font-semibold text-primary mb-2">{title}</h2>
              <p className="text-gray-700 leading-relaxed">{description}</p>
            </div>
          ))}
        </div>
      </section>
    </Layout>
  );
}