import { useState } from 'react';
import Layout from '../components/Layout';

/**
 * Contact page with a simple form. Submits data to the `/api/contact` endpoint
 * which sends an email via SendGrid. Configure SendGrid by setting the
 * environment variables SENDGRID_API_KEY and CONTACT_EMAIL_TO in your
 * deployment platform.
 */
export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [status, setStatus] = useState({ submitting: false, success: null, error: null });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus({ submitting: true, success: null, error: null });
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      if (!res.ok) {
        throw new Error('There was a problem sending your message.');
      }
      setForm({ name: '', email: '', message: '' });
      setStatus({ submitting: false, success: 'Thank you! We will be in touch soon.', error: null });
    } catch (err) {
      setStatus({ submitting: false, success: null, error: err.message });
    }
  };

  return (
    <Layout>
      <section className="max-w-xl mx-auto py-16">
        <h1 className="text-3xl sm:text-4xl font-bold mb-6 text-center">Contact Us</h1>
        <p className="text-gray-700 mb-8 text-center">
          Have a question or project in mind? Drop us a line using the form below and we’ll get back to you.
        </p>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="name" className="block mb-1 font-medium text-gray-700">
              Name
            </label>
            <input
              type="text"
              id="name"
              name="name"
              required
              value={form.name}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:border-primary"
            />
          </div>
          <div>
            <label htmlFor="email" className="block mb-1 font-medium text-gray-700">
              Email
            </label>
            <input
              type="email"
              id="email"
              name="email"
              required
              value={form.email}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:border-primary"
            />
          </div>
          <div>
            <label htmlFor="message" className="block mb-1 font-medium text-gray-700">
              Message
            </label>
            <textarea
              id="message"
              name="message"
              required
              rows={5}
              value={form.message}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:border-primary"
            />
          </div>
          <button
            type="submit"
            disabled={status.submitting}
            className="bg-primary hover:bg-primary-dark text-white px-6 py-3 rounded-md transition-colors disabled:opacity-50"
          >
            {status.submitting ? 'Sending…' : 'Send Message'}
          </button>
        </form>
        {status.success && <p className="mt-4 text-green-600">{status.success}</p>}
        {status.error && <p className="mt-4 text-red-600">{status.error}</p>}
      </section>
    </Layout>
  );
}