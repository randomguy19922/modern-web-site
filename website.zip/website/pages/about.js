import Image from 'next/image';
import Layout from '../components/Layout';

/**
 * About page describing the company history, mission, and values. Feel free to
 * adjust the copy and imagery to suit your business.
 */
export default function About() {
  return (
    <Layout>
      <section className="max-w-4xl mx-auto py-16">
        <h1 className="text-3xl sm:text-4xl font-bold mb-6 text-center">About Us</h1>
        <div className="mb-8">
          <Image
            src="/images/about.jpg"
            alt="Our team"
            width={800}
            height={450}
            className="rounded-lg"
          />
        </div>
        <p className="mb-4 text-gray-700 leading-relaxed">
          Modern Web Co was founded with one goal in mind: to deliver clean,
          modern, and effective web solutions for businesses of all sizes. Our
          team of designers, developers, and strategists bring years of
          experience to every project, ensuring that your vision is translated
          into a digital experience that performs.
        </p>
        <p className="mb-4 text-gray-700 leading-relaxed">
          We believe in craftsmanship, attention to detail, and collaboration.
          From the initial discovery call through launch day and beyond, we
          partner closely with our clients to build products that not only look
          great but also drive results. Your success is our success.
        </p>
        <p className="text-gray-700 leading-relaxed">
          Located in Taneytown, Maryland, we proudly serve local businesses and
          organizations across the United States. Get in touch to learn how we
          can help elevate your digital presence.
        </p>
      </section>
    </Layout>
  );
}