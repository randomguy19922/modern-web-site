import Layout from '../../components/Layout';
import { getAllPosts, getPostBySlug } from '../../lib/notion';

/**
 * Very basic markdown parser for demo purposes. Converts headings and newlines
 * into HTML. For a more robust solution, consider installing a markdown
 * parser such as `marked` or `remark` and using it here.
 */
function markdownToHtml(markdown) {
  let html = markdown;
  // Headings
  html = html.replace(/^### (.*$)/gim, '<h3>$1</h3>');
  html = html.replace(/^## (.*$)/gim, '<h2>$1</h2>');
  html = html.replace(/^# (.*$)/gim, '<h1>$1</h1>');
  // Bold
  html = html.replace(/\*\*(.*?)\*\*/gim, '<strong>$1</strong>');
  // Italic
  html = html.replace(/\*(.*?)\*/gim, '<em>$1</em>');
  // Line breaks
  html = html.replace(/\n/g, '<br />');
  return html.trim();
}

export default function Post({ post }) {
  return (
    <Layout>
      <article className="max-w-3xl mx-auto py-16">
        <h1 className="text-3xl sm:text-4xl font-bold mb-4">{post.title}</h1>
        <p className="text-sm text-gray-400 mb-8">
          {new Date(post.date).toLocaleDateString('en-US', {
            month: 'long',
            day: 'numeric',
            year: 'numeric',
          })}
        </p>
        <div
          className="prose prose-lg max-w-none"
          dangerouslySetInnerHTML={{ __html: markdownToHtml(post.content) }}
        />
      </article>
    </Layout>
  );
}

export async function getStaticPaths() {
  const posts = await getAllPosts();
  const paths = posts.map((post) => ({ params: { slug: post.slug } }));
  return { paths, fallback: false };
}

export async function getStaticProps({ params }) {
  const post = await getPostBySlug(params.slug);
  return { props: { post } };
}